from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton


_0 = """<b>⎚ Chill | Stripe Charge 
Card: <code>{card}</code>
Progress: 🔴 1.0 sgd
</b>"""


_50 = """<b>⎚ Chill | Stripe Charge 
Card: <code>{card}</code>
Progress: 🟠 5.4 sgd
</b>"""

_100 = """<b>⎚ Chill | Stripe Charge 

⎚ 𝐂𝐚𝐫𝐝: <code>{card}</code>
⎚ 𝐒𝐭𝐚𝐭𝐮𝐬: <b>{status}</b>
⎚ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: <b>{result}</b>
⸙ 𝐆𝐚𝐭𝐞𝐰𝐚𝐲: <code>Chill</code>
━━━━━━━━
⎚ 𝐏𝐫𝐨𝐱𝐢: Live!✅
⎚ 𝐂𝐡𝐞𝐤𝐞𝐝 𝐁𝐲: @{user}
⎚ 𝐓𝐚𝐤𝐞𝐧: <b>{time}s</b>
━━━━━━━━
⎚ Create <b><a href="tg://resolve?domain=RexAwait">𝗿𝗲𝘅 hᴀᴡᴀɪɪ |「💻」</a></b>
</b>"""
